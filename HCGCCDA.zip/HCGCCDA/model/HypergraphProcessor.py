import numpy as np
import torch
from torch_geometric.nn import HypergraphConv
import torch.nn as nn

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


class Hyperrna(nn.Module):
    def __init__(self, in_circfeat_size, in_disfeat_size ,outfeature_size, heads):
        super(Hyperrna, self).__init__()
        self.in_circfeat_size = in_circfeat_size
        self.in_disfeat_size = in_disfeat_size
        self.outfeature_size = outfeature_size
        self.heads = heads
        self.conv1 = HypergraphConv(self.outfeature_size+self.heads * self.outfeature_size+661, 1024, use_attention=False, heads=1, concat=True, negative_slope=0.2,
                                    dropout=0.5, bias=True)
        self.conv2 = HypergraphConv(1024, 768, use_attention=False, heads=1, concat=True, negative_slope=0.2,
                                    dropout=0.5, bias=True)
        self.conv3 = HypergraphConv(768, 512, use_attention=False, heads=1, concat=True, negative_slope=0.2,
                                    dropout=0.5, bias=True)
        # 定义参数初始化函数
        def init_weights(m):
            if type(m) == nn.Linear:
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif type(m) == nn.Conv2d:
                nn.init.uniform_(m.weight)

        # 初始化
        self.conv1.apply(init_weights)
        self.conv2.apply(init_weights)
        self.conv3.apply(init_weights)

    def process_hypergraph(self, triplets, x):

        adj1_matrix = triplets

        adj1_matrix = adj1_matrix.clone().detach()

        hyperedge_index = torch.nonzero(adj1_matrix.T, as_tuple=True)

        hyperedge_index = torch.stack(hyperedge_index)

        hyperedge_index = hyperedge_index.to(x.device)

        output = self.conv1(x, hyperedge_index)
        output = self.conv2(output, hyperedge_index)
        output = self.conv3(output, hyperedge_index)


        return output

    def forward(self, X, triplet):

        output = self.process_hypergraph(triplet, X)

        return output


class Hyperdis(nn.Module):
    def __init__(self, in_circfeat_size, in_disfeat_size ,outfeature_size, heads):
        super(Hyperdis, self).__init__()
        self.in_circfeat_size = in_circfeat_size  # 3077
        self.in_disfeat_size = in_disfeat_size  # 313
        self.outfeature_size = outfeature_size  # 512
        self.heads = heads
        self.conv1 = HypergraphConv(self.outfeature_size+self.heads * self.outfeature_size+100, 1024, use_attention=False, heads=1, concat=True, negative_slope=0.2,
                                    dropout=0.5, bias=True)
        self.conv2 = HypergraphConv(1024, 768, use_attention=False, heads=1, concat=True, negative_slope=0.2,
                                    dropout=0.5, bias=True)
        self.conv3 = HypergraphConv(768, 512, use_attention=False, heads=1, concat=True, negative_slope=0.2,
                                    dropout=0.5, bias=True)
        # 定义参数初始化函数
        def init_weights(m):
            if type(m) == nn.Linear:
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif type(m) == nn.Conv2d:
                nn.init.uniform_(m.weight)

        # 初始化
        self.conv1.apply(init_weights)

    def process_hypergraph(self, triplets, x):

        adj1_matrix = triplets

        adj1_matrix = adj1_matrix.clone().detach()

        hyperedge_index = torch.nonzero(adj1_matrix.T, as_tuple=True)

        hyperedge_index = torch.stack(hyperedge_index)

        hyperedge_index = hyperedge_index.to(x.device)

        output = self.conv1(x, hyperedge_index)
        output = self.conv2(output, hyperedge_index)
        output = self.conv3(output, hyperedge_index)
        return output

    def forward(self, X, triplet):

        output = self.process_hypergraph(triplet, X)

        return output