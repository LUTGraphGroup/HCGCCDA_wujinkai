import math

import torch
import torch.nn as nn
import torch.nn.functional as F
from GATlayer import GATConv
from utils import train_features_choose, test_features_choose, build_heterograph
import pandas as pd
from HypergraphProcessor import Hyperrna, Hyperdis
from GCN import GCNrna

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

class MLP(nn.Module):
    def __init__(self, embedding_size, drop_rate):
        super(MLP, self).__init__()
        self.embedding_size = embedding_size  # 2807
        self.drop_rate = drop_rate

        def init_weights(m):
            if type(m) == nn.Linear:
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif type(m) == nn.Conv2d:
                nn.init.uniform_(m.weight)

        hidden_sizes = [self.embedding_size // 2, self.embedding_size // 4, self.embedding_size // 8,
                        self.embedding_size // 16]

        layers = []
        input_size = self.embedding_size

        for size in hidden_sizes:
            layers.append(nn.Linear(input_size, size))
            layers.append(nn.LeakyReLU())
            layers.append(nn.Dropout(self.drop_rate))
            input_size = size

        layers.append(nn.Linear(input_size, 1, bias=False))
        layers.append(nn.Sigmoid())

        self.mlp_prediction = nn.Sequential(*layers).to(device)
        self.mlp_prediction.apply(init_weights)

    def forward(self, rd_features_embedding):
        predict_result = self.mlp_prediction(rd_features_embedding)
        return predict_result

class GAT(nn.Module):
    def __init__(self, in_circfeat_size, in_disfeat_size,  outfeature_size, heads, drop_rate,
                 negative_slope,
                 features_embedding_size, negative_times):
        super(GAT, self).__init__()
        self.in_circfeat_size = in_circfeat_size  # 3077
        self.in_disfeat_size = in_disfeat_size  # 313

        self.outfeature_size = outfeature_size  # 128
        self.heads = heads  # 8
        self.drop_rate = drop_rate  # 0.1
        self.negative_slope = negative_slope  # 0.3

        self.features_embedding_size = features_embedding_size  # 2807

        self.negative_times = negative_times
        self.tanh =  nn.Tanh()
        self.att_layer = GATConv(self.outfeature_size, self.outfeature_size, self.heads, self.drop_rate,
                                 self.drop_rate, self.negative_slope)

        self.HGCrna = Hyperrna(self.in_circfeat_size, self.in_disfeat_size,self.outfeature_size,self.heads)
        self.HGCdis = Hyperdis(self.in_circfeat_size, self.in_disfeat_size,self.outfeature_size,self.heads)

        self.GCNrna = GCNrna(1024,768)

        self.W_rna1 = nn.Parameter(torch.zeros(size=(self.in_circfeat_size, self.outfeature_size)))
        self.W_dis1 = nn.Parameter(torch.zeros(size=(self.in_disfeat_size, self.outfeature_size)))
        self.W_rna2 = nn.Parameter(torch.zeros(size=(self.in_circfeat_size, self.outfeature_size)))
        self.W_dis2 = nn.Parameter(torch.zeros(size=(self.in_disfeat_size, self.outfeature_size)))
        self.W_rna3 = nn.Parameter(torch.zeros(size=(self.outfeature_size+self.heads * self.outfeature_size+661, 1024)))
        self.W_dis3 = nn.Parameter(torch.zeros(size=(self.outfeature_size+self.heads * self.outfeature_size+100, 1024)))

        nn.init.xavier_uniform_(self.W_rna3.data, gain=1.414)
        nn.init.xavier_uniform_(self.W_dis3.data, gain=1.414)
        nn.init.xavier_uniform_(self.W_rna1.data, gain=1.414)
        nn.init.xavier_uniform_(self.W_dis1.data, gain=1.414)
        nn.init.xavier_uniform_(self.W_rna2.data, gain=1.414)
        nn.init.xavier_uniform_(self.W_dis2.data, gain=1.414)


        self.mlp_prediction = MLP(self.features_embedding_size, self.drop_rate)

        self.init_weights()

    def init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Conv2d):
                nn.init.uniform_(m.weight)

    def forward(self, gcd, circ_feature_tensor, dis_feature_tensor,similarity_Graph_c,similarity_Graph_d,circ,dis,
                rel_matrix, train_model):
        # circ_circ_f = self.HGCrna(circ_feature_tensor, similarity_Graph_c)
        # dis_dis_f = self.HGCdis(dis_feature_tensor, similarity_Graph_d)

        circ_circ_f1 = circ.mm(self.W_rna1)
        dis_dis_f1 = dis.mm(self.W_dis1)
        circ_circ_f1 = self.tanh(circ_circ_f1)
        dis_dis_f1 = self.tanh(dis_dis_f1)
        h_c_d_feature1 = torch.cat((circ_circ_f1, dis_dis_f1), dim=0)#761*128

        circ_circ_f2 = circ.mm(self.W_rna2)
        dis_dis_f2 = dis.mm(self.W_dis2)
        h_c_d_feature2 = torch.cat((circ_circ_f2, dis_dis_f2), dim=0)
        rcd = self.att_layer(gcd, h_c_d_feature2)  # 3390*8*128
        h_c_d_feature2 = rcd.view(761, 1, self.heads, -1)
        h_c_d_feature2 = h_c_d_feature2.view(761, self.heads * self.outfeature_size)#761*1024

        h_c_d_feature = torch.cat((h_c_d_feature1, h_c_d_feature2), dim=1)#761*1152

        h_c_feature, h_d_feature = torch.split(h_c_d_feature, [661, 100], dim=0)

        h_c_feature = torch.cat((h_c_feature, circ_feature_tensor),dim=1)
        h_d_feature = torch.cat((h_d_feature, dis_feature_tensor),dim=1)

        circ_circ_f = self.HGCrna(h_c_feature, similarity_Graph_c)
        dis_dis_f = self.HGCdis(h_d_feature, similarity_Graph_d)
        cnn_output1 = torch.cat((circ_circ_f, dis_dis_f), dim=0)#761*512

        circ_feature_tensor = h_c_feature.mm(self.W_rna3)
        dis_feature_tensor = h_d_feature.mm(self.W_dis3)
        h_1 = torch.cat((circ_feature_tensor, dis_feature_tensor), dim=0) #761*1024

        cnn_output2 = self.GCNrna(gcd,h_1)

        cnn_output = torch.cat((cnn_output1, cnn_output2), dim=1)


        if train_model:
            train_features_inputs, train_lable = train_features_choose(rel_matrix, cnn_output, self.negative_times)
            train_mlp_result = self.mlp_prediction(train_features_inputs)
            return train_mlp_result, train_lable
        else:
            test_features_inputs, test_lable = test_features_choose(rel_matrix, cnn_output)
            test_mlp_result = self.mlp_prediction(test_features_inputs)
            return test_mlp_result, test_lable










