# HCGCCDA: Prediction of circRNA-disease Associations based on the Combination of Hypergraph Convolution and Graph Convolution

## Dependecies
- Python 3.9
- dgl 0.9.1
- dgl-cuda 0.9.1
- numpy 1.22.3
- pytorch 1.13.0
- pytorch-cuda 11.6
- pandas 1.4.2

## Dataset
circRNA-disease associations : rna+dis+matrix.xlsx
circRNA features : rna_GaussianSimilarity.xlsx, circ.xlsx
disease features  : dis_GaussianSimilarity.xlsx, dis.xlsx
C_hc : similarity_Graph_c.xlsx
D_hc : similarity_Graph_d.xlsx

## How to run?
```
Run main.py
```
